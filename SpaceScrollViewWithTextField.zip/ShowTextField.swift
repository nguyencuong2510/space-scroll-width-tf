//
//  ShowTextField.swift
//  ScrollView
//
//  Created by admin on 10/10/18.
//  Copyright © 2018 cuongnv. All rights reserved.
//

import UIKit

class ShowTextField: UIScrollView {
    
    
    @IBOutlet var tfInput: [UITextField]!
    
    private var isShowKeyboard = false
    private var frameds = CGRect.zero
    
    @IBInspectable var heightSpaceTextField: CGFloat = 10
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
        NotificationCenter.default.addObserver(self, selector: #selector(showKeyBoard(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(hideKeyBroad(noti:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    override func draw(_ rect: CGRect) {
        tfInput.forEach { $0.delegate = self }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc private func showKeyBoard(notification: Notification) {
        
        guard !isShowKeyboard, let uInfo = notification.userInfo else { return }
        isShowKeyboard = true
        
        guard let frameKeyboard = uInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect
        else { return }
        
        if (frameds.maxY - frameKeyboard.origin.y) > 0  {
            self.contentInset.bottom += frameKeyboard.height + heightSpaceTextField
        }
    }
    
    @objc private func hideKeyBroad(noti: Notification) {
        isShowKeyboard = false
        self.contentInset.bottom = 0
    }
}

extension ShowTextField: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        frameds = textField.frame
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
